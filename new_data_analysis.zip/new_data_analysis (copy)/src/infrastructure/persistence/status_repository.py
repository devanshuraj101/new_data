from src.domain.ports import StatusRepositoryPort


class InMemoryStatusRepository(StatusRepositoryPort):

    def __init__(self):
        self.storage = {}

    async def save_status(self, request_id: str, status: str):
        self.storage[request_id] = status

    async def get_status(self, request_id: str):
        return self.storage.get(request_id)