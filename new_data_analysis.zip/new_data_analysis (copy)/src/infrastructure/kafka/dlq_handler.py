import json
from aiokafka import AIOKafkaConsumer
from infrastructure.kafka.topics import DLQ_TOPIC


class DLQHandler:

    async def start(self):

        consumer = AIOKafkaConsumer(
            DLQ_TOPIC,
            bootstrap_servers="localhost:9092",
            group_id="dlq-handler"
        )

        await consumer.start()

        try:
            async for msg in consumer:
                data = json.loads(msg.value.decode())
                print("⚠ DLQ Message:", data)

        finally:
            await consumer.stop()