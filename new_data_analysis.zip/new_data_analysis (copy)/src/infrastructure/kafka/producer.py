import json
import logging
from aiokafka import AIOKafkaProducer
from aiokafka.errors import KafkaError
from src.infrastructure.kafka.topics import MAIN_TOPIC

logger = logging.getLogger(__name__)


class KafkaProducerAdapter:
    def __init__(self, bootstrap_servers: str):
        self.bootstrap_servers = bootstrap_servers
        self.producer: AIOKafkaProducer | None = None

    async def start(self):
        # Producer should be instantiated here, not in __init__,
        # since the event loop may not exist yet at construction time.
        self.producer = AIOKafkaProducer(
            bootstrap_servers=self.bootstrap_servers,
            acks="all",
            retry_backoff_ms=300,
            enable_idempotence=True,  # Guarantees exactly-once delivery; implies acks="all"
        )
        await self.producer.start()
        logger.info("Kafka producer started.")

    async def stop(self):
        if self.producer:
            await self.producer.stop()
            logger.info("Kafka producer stopped.")

    async def publish(self, request):
        if not self.producer:
            raise RuntimeError("Producer is not started. Call start() first.")

        try:
            payload = self._serialize(request)
            await self.producer.send_and_wait(MAIN_TOPIC, payload)
            logger.debug("Message published to topic '%s'.", MAIN_TOPIC)
        except KafkaError as e:
            logger.error("Failed to publish message to Kafka: %s", e)
            raise

    @staticmethod
    def _serialize(request) -> bytes:
        # Support both plain objects and dataclasses/Pydantic models gracefully
        if hasattr(request, "model_dump"):        # Pydantic v2
            data = request.model_dump()
        elif hasattr(request, "dict"):            # Pydantic v1
            data = request.dict()
        elif hasattr(request, "__dict__"):
            data = request.__dict__
        else:
            data = dict(request)

        return json.dumps(data, default=str).encode("utf-8")