import json
from aiokafka import AIOKafkaConsumer
from domain.models import AnalysisRequest

class AnalysisWorker:

    def __init__(self, engine, notifier):
        self.engine = engine
        self.notifier = notifier

    async def start(self):
        consumer = AIOKafkaConsumer(
            "data-analysis-topic",
            bootstrap_servers="localhost:9092",
            group_id="analysis-workers",
            enable_auto_commit=False
        )

        await consumer.start()

        try:
            async for msg in consumer:
                data = json.loads(msg.value.decode())

                request = AnalysisRequest(**data)

                try:
                    result = await self.engine.run_analysis(request)

                    await self.notifier.notify(
                        "Analysis Complete",
                        "Analysis completed successfully",
                        request.request_id
                    )

                    await consumer.commit()

                except Exception as e:
                    print("Failed:", e)
                    # Do NOT commit → retry
        finally:
            await consumer.stop()