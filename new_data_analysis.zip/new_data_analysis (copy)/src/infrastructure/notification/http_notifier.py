import requests
from src.domain.ports import NotificationPort


class HttpNotifier(NotificationPort):

    def __init__(self, base_url: str):
        self.base_url = base_url

    async def notify(self, request_id: str, status: str, message: str):

        payload = {
            "requestId": request_id,
            "status": status,
            "message": message
        }

        requests.post(
            f"{self.base_url}/api/notification/send",
            json=payload,
            timeout=5
        )