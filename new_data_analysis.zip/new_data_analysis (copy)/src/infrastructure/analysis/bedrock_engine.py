import os
import asyncio
import pybreaker

from src.domain.ports import AnalysisEnginePort
from src.domain.exceptions import AnalysisFailedException

from smolagents import CodeAgent, AmazonBedrockServerModel
import boto3
from botocore.config import Config


class BedrockAnalysisEngine(AnalysisEnginePort):

    def __init__(self, model_id: str):

        config = Config(
            read_timeout=600,
            connect_timeout=60,
            retries={'max_attempts': 5}
        )

        bedrock_client = boto3.client(
            service_name='bedrock-runtime',
            region_name='us-east-1',
            config=config
        )

        model = AmazonBedrockServerModel(
            model_id=model_id,
            client=bedrock_client,
            inferenceConfig={"maxTokens": 65536}
        )

        self.agent = CodeAgent(
            tools=[],
            model=model,
            additional_authorized_imports=[
                "numpy", "pandas", "matplotlib.pyplot",
                "seaborn", "scipy", "sklearn"
            ],
        )

        # 🔥 Circuit Breaker
        self.breaker = pybreaker.CircuitBreaker(
            fail_max=5,
            reset_timeout=60  # seconds
        )

    async def analyze(self, request):

        try:
            # Run blocking agent in thread
            loop = asyncio.get_running_loop()

            return await loop.run_in_executor(
                None,
                self.breaker.call,
                lambda: self.agent.run(
                    f"File: {request.file_path}\nQuery: {request.query}"
                )
            )

        except pybreaker.CircuitBreakerError:
            raise AnalysisFailedException("Bedrock circuit open")

        except Exception as e:
            raise AnalysisFailedException(str(e))