class ProcessAnalysisUseCase:

    def __init__(self, engine, notifier, repository):
        self.engine = engine
        self.notifier = notifier
        self.repository = repository

    async def execute(self, request):
        await self.repository.save_status(request.request_id, "PROCESSING")

        result = await self.engine.analyze(request)

        await self.repository.save_status(request.request_id, "COMPLETED")
        await self.notifier.notify(
            request.request_id,
            "COMPLETED",
            "Analysis completed successfully"
        )

        return result