class SubmitAnalysisUseCase:

    def __init__(self, queue, repository):
        self.queue = queue
        self.repository = repository

    async def execute(self, request):
        await self.repository.save_status(request.request_id, "QUEUED")
        await self.queue.publish(request)
        return request.request_id