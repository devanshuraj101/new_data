from abc import ABC, abstractmethod
from src.domain.models import AnalysisRequest

class QueuePort(ABC):
    @abstractmethod
    async def publish(self, request: AnalysisRequest):
        pass


class AnalysisEnginePort(ABC):
    @abstractmethod
    async def analyze(self, request: AnalysisRequest) -> str:
        pass


class NotificationPort(ABC):
    @abstractmethod
    async def notify(self, request_id: str, status: str, message: str):
        pass


class StatusRepositoryPort(ABC):
    @abstractmethod
    async def save_status(self, request_id: str, status: str):
        pass