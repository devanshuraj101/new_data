from dataclasses import dataclass
from datetime import datetime

@dataclass
class AnalysisRequest:
    request_id: str
    file_path: str
    query: str
    username: str
    thread_id: str
    created_at: datetime
    retry_count: int = 0