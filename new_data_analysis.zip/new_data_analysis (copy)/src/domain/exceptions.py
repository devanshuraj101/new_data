class AnalysisFailedException(Exception):
    pass


class MaxRetryExceededException(Exception):
    pass