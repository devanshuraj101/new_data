# adapters/mcp/mcp_controller.py

from fastmcp import FastMCP
import uuid
from datetime import datetime
from src.domain.models import AnalysisRequest

mcp = FastMCP("Data Analysis Server")


def register_routes(container):

    @mcp.tool()
    async def analyze_data(file_path: str, query: str, username: str, thread_id: str):

        request = AnalysisRequest(
            request_id=str(uuid.uuid4()),
            file_path=file_path,
            query=query,
            username=username,
            thread_id=thread_id,
            created_at=datetime.utcnow()
        )

        submit_use_case = await container.submit_use_case()

        request_id = await submit_use_case.execute(request)

        return f"Submitted. Request ID: {request_id}"

    return mcp