import asyncio
from src.container import Container
from src.adapters.mcp.mcp_controller import register_routes


def main():

    container = Container()

    container.config.kafka.bootstrap.from_env("KAFKA_BOOTSTRAP", "localhost:9092")
    container.config.bedrock.model_id.from_env("BEDROCK_MODEL_ID")
    container.config.notification.base_url.from_env("NOTIFICATION_URL")

    # await container.init_resources()

    mcp = register_routes(container)
    mcp.run(transport="sse", host="0.0.0.0", port=8002)

    # await container.shutdown_resources()


if __name__ == "__main__":
    # asyncio.run(main())
    main()