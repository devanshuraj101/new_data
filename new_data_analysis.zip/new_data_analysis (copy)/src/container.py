from dependency_injector import containers, providers

from src.infrastructure.kafka.producer import KafkaProducerAdapter, init_kafka_producer
from src.infrastructure.analysis.bedrock_engine import BedrockAnalysisEngine
from src.infrastructure.notification.http_notifier import HttpNotifier
from src.infrastructure.persistence.status_repository import InMemoryStatusRepository
from src.application.use_cases.submit_analysis import SubmitAnalysisUseCase
from src.application.use_cases.process_analysis import ProcessAnalysisUseCase


class Container(containers.DeclarativeContainer):

    wiring_config = containers.WiringConfiguration(
        packages=["src.adapters", "worker"]
    )

    # ---------------- Config ----------------
    config = providers.Configuration()

    # ---------------- Infrastructure ----------------
    kafka_producer = providers.Resource(
        init_kafka_producer,                        # <-- async generator, not the class
        bootstrap_servers=config.kafka.bootstrap,
    )

    repository = providers.Singleton(
        InMemoryStatusRepository,
    )

    analysis_engine = providers.Singleton(
        BedrockAnalysisEngine,
        model_id=config.bedrock.model_id,
    )

    notifier = providers.Singleton(
        HttpNotifier,
        base_url=config.notification.base_url,
    )

    # ---------------- Use Cases ----------------
    submit_use_case = providers.Factory(
        SubmitAnalysisUseCase,
        queue=kafka_producer,
        repository=repository,
    )

    process_use_case = providers.Factory(
        ProcessAnalysisUseCase,
        engine=analysis_engine,
        notifier=notifier,
        repository=repository,
    )