import os


class Settings:

    KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP", "localhost:9092")
    BASE_NOTIFICATION_URL = os.getenv("NOTIFICATION_URL", "http://localhost:8080")
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))


settings = Settings()