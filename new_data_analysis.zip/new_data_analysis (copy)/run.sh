 docker compose up -d
