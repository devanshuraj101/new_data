#!/usr/bin/env python3
"""
Kafka Topic Setup Script

Creates required topics for Data Analysis System:
- Main topic
- Retry topic
- Dead Letter Queue topic

Safe to run multiple times (idempotent).
"""

import os
import sys
from kafka.admin import KafkaAdminClient, NewTopic
from kafka.errors import TopicAlreadyExistsError


BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP", "localhost:9092")

MAIN_TOPIC = "data-analysis-jobs"
RETRY_TOPIC = "data-analysis-retry"
DLQ_TOPIC = "data-analysis-dlq"


def create_topic(admin_client, name, partitions, replication, config=None):
    topic = NewTopic(
        name=name,
        num_partitions=partitions,
        replication_factor=replication,
        topic_configs=config or {}
    )

    try:
        admin_client.create_topics([topic])
        print(f"✅ Created topic: {name}")
    except TopicAlreadyExistsError:
        print(f"⚠ Topic already exists: {name}")


def main():
    print("🔧 Connecting to Kafka:", BOOTSTRAP_SERVERS)

    try:
        admin = KafkaAdminClient(
            bootstrap_servers=BOOTSTRAP_SERVERS,
            client_id="analysis-admin"
        )
    except Exception as e:
        print("❌ Failed to connect to Kafka:", e)
        sys.exit(1)

    print("🚀 Creating topics...")

    # ----------------------------
    # Main Topic
    # ----------------------------
    create_topic(
        admin,
        MAIN_TOPIC,
        partitions=1,  # strict one-by-one processing
        replication=1,
        config={
            "cleanup.policy": "delete",
            "retention.ms": str(7 * 24 * 60 * 60 * 1000)  # 7 days
        }
    )

    # ----------------------------
    # Retry Topic
    # ----------------------------
    create_topic(
        admin,
        RETRY_TOPIC,
        partitions=1,
        replication=1,
        config={
            "cleanup.policy": "delete",
            "retention.ms": str(3 * 24 * 60 * 60 * 1000)  # 3 days
        }
    )

    # ----------------------------
    # Dead Letter Queue
    # ----------------------------
    create_topic(
        admin,
        DLQ_TOPIC,
        partitions=1,
        replication=1,
        config={
            "cleanup.policy": "delete",
            "retention.ms": str(14 * 24 * 60 * 60 * 1000),  # 14 days
            "min.insync.replicas": "1"
        }
    )

    admin.close()
    print("🎉 Kafka setup completed successfully.")


if __name__ == "__main__":
    main()