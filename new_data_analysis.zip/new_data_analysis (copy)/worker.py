import asyncio
import json
import logging
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from aiokafka.errors import KafkaError

from src.infrastructure.kafka.topics import MAIN_TOPIC, RETRY_TOPIC, DLQ_TOPIC
from src.config.settings import settings
from src.container import Container

logger = logging.getLogger(__name__)


async def start_worker():
    container = Container()
    container.config.kafka.bootstrap.from_env("KAFKA_BOOTSTRAP", default="localhost:9092")
    container.config.bedrock.model_id.from_env("BEDROCK_MODEL_ID")
    container.config.notification.base_url.from_env("NOTIFICATION_URL")
    await container.init_resources()

    process_use_case = container.process_use_case()

    consumer = AIOKafkaConsumer(
        MAIN_TOPIC,
        bootstrap_servers=settings.KAFKA_BOOTSTRAP,
        group_id="analysis-workers",
        enable_auto_commit=False,
        auto_offset_reset="earliest",       # Explicit: don't silently skip messages
        max_poll_records=1,
        session_timeout_ms=30000,
        heartbeat_interval_ms=10000,
    )

    producer = AIOKafkaProducer(
        bootstrap_servers=settings.KAFKA_BOOTSTRAP,
        acks="all",                          # Was missing: ensures durability
        enable_idempotence=True,             # Prevents duplicate messages on retry
    )

    await consumer.start()
    await producer.start()
    logger.info("Worker started. Listening on topic '%s'.", MAIN_TOPIC)

    try:
        async for msg in consumer:
            try:
                data = json.loads(msg.value.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                # Poison pill — log and commit so it doesn't block the consumer forever
                logger.error(
                    "Failed to deserialize message at offset %s: %s. Skipping.",
                    msg.offset, e
                )
                await consumer.commit()
                continue

            try:
                await process_use_case.execute(data)
                await consumer.commit()
                logger.debug("Message at offset %s processed successfully.", msg.offset)

            except Exception as e:
                retries = data.get("retry_count", 0) + 1
                data["retry_count"] = retries
                target_topic = DLQ_TOPIC if retries >= settings.MAX_RETRIES else RETRY_TOPIC

                logger.warning(
                    "Processing failed (attempt %s/%s). Routing to '%s'. Error: %s",
                    retries, settings.MAX_RETRIES, target_topic, e,
                )

                try:
                    await producer.send_and_wait(
                        target_topic,
                        json.dumps(data, default=str).encode("utf-8"),
                    )
                except KafkaError as kafka_err:
                    # Do NOT commit — message will be redelivered on restart
                    logger.error(
                        "Failed to route message to '%s': %s. Offset NOT committed.",
                        target_topic, kafka_err,
                    )
                    continue

                await consumer.commit()

    except asyncio.CancelledError:
        logger.info("Worker cancelled. Shutting down gracefully.")
    except Exception as e:
        logger.critical("Unexpected error in worker loop: %s", e, exc_info=True)
        raise
    finally:
        await consumer.stop()
        await producer.stop()
        await container.shutdown_resources()
        logger.info("Worker shut down.")


if __name__ == "__main__":
    asyncio.run(start_worker())